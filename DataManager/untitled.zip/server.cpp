#include "server.h"

static inline qint32 ArrayToInt(QByteArray source);

Server::Server(QObject *parent) : QObject(parent)
{
    server = new QTcpServer(this);
    qDebug() << "Server: signal connection" << connect(server, SIGNAL(newConnection()), this, SLOT(newConnection()));
    qDebug() << "Server: listening:" << server->listen(QHostAddress::Any, 1024);
}

void Server::newConnection()
{
    qDebug() << "Server: Connection attempt reqcognized";
    while (server->hasPendingConnections())
    {

        QTcpSocket *socket = server->nextPendingConnection();
        connect(socket, SIGNAL(readyRead()), SLOT(readyRead()));
        connect(socket, SIGNAL(disconnected()), SLOT(disconnected()));
        QByteArray *buffer = new QByteArray();
        qint32 *s = new qint32(0);
        buffers.insert(socket, buffer);
        sizes.insert(socket, s);
        qDebug() << "Server: Connection made";
    }
}

void Server::readyRead()
{
    qDebug() << "Server: read data";
}

void Server::disconnected()
{
    QTcpSocket *socket = static_cast<QTcpSocket*>(sender());
    QByteArray *buffer = buffers.value(socket);
    qint32 *s = sizes.value(socket);
    socket->deleteLater();
    delete buffer;
    delete s;
}
